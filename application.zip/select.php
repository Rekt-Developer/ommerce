<?php 
session_start();
include("connection.php");

if(isset($_POST["id"]) && isset($_POST['ip'])){

	$output = '';  
    $q = "SELECT * FROM products WHERE id = '".$_POST["id"]."'"; 
    $data= mysqli_query($conn, $q);
    $res = mysqli_fetch_array($data);
    $id= $res['id'];
    $ip= $_POST['ip'];
    $_SESSION['sess_ip']= $ip;
    $name= $res['product_name'];
    $price= $res['product_price'];
    $image= $res['product_image'];
    $q2= "INSERT INTO cart VALUES('$id', '$ip', '$name', '$price', '$image')";
    $q3= "SELECT * FROM cart WHERE product_id = '$id' AND ip='$ip'";
    $data3= mysqli_query($conn, $q3);
    $total= mysqli_num_rows($data3);
    if($total == 0){
    	    if(mysqli_query($conn, $q2)){
    	    	echo "Product Added in Cart";
    	    }
    }
    else{
    	echo "Product Already in Cart";
    }
}
?>

