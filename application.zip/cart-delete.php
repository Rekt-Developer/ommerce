<?php 
session_start();
include("connection.php");
$ip= $_SESSION['sess_ip'];
$id= $_REQUEST['id'];
//echo $id;

$q = "DELETE from cart WHERE ip='$ip' and product_id='$id'";
$data= mysqli_query($conn, $q);
echo "Removed";
?>