<?php
$servername= "localhost";
$username= "hemaluser";
$password= "hemalpass";
$dbname= "lakilaka";


$conn= mysqli_connect($servername,$username,$password,$dbname);

if($conn){
	echo "";
}
else{
	die("Connection failed ".mysql_connect_error());
}

?>