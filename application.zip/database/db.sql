-- MySQL dump 10.13  Distrib 5.7.26, for Linux (x86_64)
--
-- Host: localhost    Database: myapp
-- ------------------------------------------------------
-- Server version	5.7.26-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cart` (
  `product_id` int(11) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `product_name` varchar(20) DEFAULT NULL,
  `product_price` varchar(20) DEFAULT NULL,
  `product_image` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES (2,'157.33.169.16','Sunflower Oil','50','1560280713_of1.png'),(1,'157.33.169.16','Moong ','25','1560271954_of.png'),(1,'157.33.188.78','Moong ','25','1560271954_of.png'),(2,'157.33.169.175','Sunflower Oil','50','1560280713_of1.png'),(1,'157.33.185.153','Moong ','25','1560271954_of.png'),(2,'157.33.185.153','Sunflower Oil','50','1560280713_of1.png'),(2,'157.33.188.157','Sunflower Oil','50','1560280713_of1.png'),(3,'157.33.188.157','Soya Chunks','45','1590262123_of3.png'),(1,'157.33.187.200','Moong ','25','1560271954_of.png'),(1,'157.33.165.21','Moong ','25','1560271954_of.png'),(3,'157.33.165.21','Soya Chunks','45','1590262123_of3.png'),(2,'49.35.85.223','Sunflower Oil','50','1560280713_of1.png'),(6,'49.35.85.223','Dabur Honey','100','1560323321_of12.png'),(3,'49.35.85.223','Soya Chunks','45','1590262123_of3.png'),(2,'49.35.209.128','Sunflower Oil','50','1560280713_of1.png'),(1,'49.35.209.128','Moong ','25','1560271954_of.png');
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crowd_estimation`
--

DROP TABLE IF EXISTS `crowd_estimation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crowd_estimation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_id` int(11) DEFAULT NULL,
  `crowd` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crowd_estimation`
--

LOCK TABLES `crowd_estimation` WRITE;
/*!40000 ALTER TABLE `crowd_estimation` DISABLE KEYS */;
INSERT INTO `crowd_estimation` VALUES (1,3,4),(2,5,2);
/*!40000 ALTER TABLE `crowd_estimation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'Shahunagar'),(2,'Sambhajinagar'),(3,'Nigdi'),(4,'Chinchwad Station'),(5,'Chinchwad Gaon'),(6,'Akurdi Gaon'),(7,'Akurdi'),(8,'Shivtejnagar'),(9,'Pimpri'),(10,'Pimpri Gaon');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_id` int(11) DEFAULT NULL,
  `customer_name` varchar(50) DEFAULT NULL,
  `customer_email` varchar(50) DEFAULT NULL,
  `customer_phone` varchar(15) DEFAULT NULL,
  `pay_id` varchar(30) DEFAULT NULL,
  `order_list` text,
  `order_status` varchar(20) DEFAULT NULL,
  `order_time` varchar(20) DEFAULT NULL,
  `address` text,
  `total_price` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,1,'Hemal Gokhale','gokhalehemal11@gmail.com','08149992059','MOJO0705Q05N89781417','Moong  Qty: 1,Soya Chunks Qty: 3,','Ready','05/07/2020 14:23:35','Shahunagar\r\nD6/4 Hdfc Colony','160'),(2,1,'Hemal Gokhale','gokhalehemal11@gmail.com','08149992059','MOJO0705205N89781581','Sunflower Oil Qty: 1,','Not Started','05/07/2020 23:29:12','Shahunagar\r\nD6/4 Hdfc Colony','50'),(6,1,'Hemal Gokhale','gokhalehemal11@gmail.com','08149992059','MOJO0707705N45021091','Sunflower Oil Qty: 2,Moong  Qty: 3,','Not Started','07/07/2020 09:37:34','Shahunagar\r\nD6/4 Hdfc Colony','175'),(7,1,'Hemal Gokhale','gokhalehemal11@gmail.com','08149992059','MOJO0707705N45021091','Sunflower Oil Qty: 2,Moong  Qty: 3,','Not Started','07/07/2020 09:40:13','Shahunagar\r\nD6/4 Hdfc Colony','175'),(8,1,'Hemal Gokhale','gokhalehemal11@gmail.com','08149992059','MOJO0707705N45021091','Sunflower Oil Qty: 2,Moong  Qty: 3,','Not Started','07/07/2020 09:41:19','Shahunagar\r\nD6/4 Hdfc Colony','175'),(9,1,'Hemal Gokhale','gokhalehemal11@gmail.com','08149992059','MOJO0707705N45021091','Sunflower Oil Qty: 2,Moong  Qty: 3,','Not Started','07/07/2020 09:44:20','Shahunagar\r\nD6/4 Hdfc Colony','175'),(10,1,'Hemal Gokhale','gokhalehemal11@gmail.com','08149992059','MOJO0707705N45021091','Sunflower Oil Qty: 2,Moong  Qty: 3,','Not Started','07/07/2020 09:45:35','Shahunagar\r\nD6/4 Hdfc Colony','175');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_id` int(11) DEFAULT NULL,
  `product_name` varchar(30) DEFAULT NULL,
  `product_category` varchar(30) DEFAULT NULL,
  `product_price` varchar(15) DEFAULT NULL,
  `product_image` varchar(20) DEFAULT NULL,
  `product_status` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,'Moong ','Wines','25','1560271954_of.png','Available'),(2,1,'Sunflower Oil','Wines','50','1560280713_of1.png','Available'),(3,1,'Soya Chunks','Wines','45','1590262123_of3.png','Available'),(6,1,'Dabur Honey','Soaps and Shampoos','100','1560323321_of12.png','Available');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendors`
--

DROP TABLE IF EXISTS `vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `category` varchar(30) DEFAULT NULL,
  `address` varchar(70) DEFAULT NULL,
  `phone_no` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendors`
--

LOCK TABLES `vendors` WRITE;
/*!40000 ALTER TABLE `vendors` DISABLE KEYS */;
INSERT INTO `vendors` VALUES (1,'Sample 1','Grocery Store','Shaunagar, Near Sambhaji nagar link road, Chinchwad','1234567890','hemal@gmail.com','hemal123');
/*!40000 ALTER TABLE `vendors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-07  9:47:21
