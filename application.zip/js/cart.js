$(function(){

$('.add-to-cart').on('click', function () {
        var cart = $('.shopping-cart a span small');
        //var imgtodrag = $(this).parent('.item').find("img").eq(0);
       // cart.text("+");
        var id= $(this).attr('id');
        console.log(id);
        $.getJSON("https://api.ipify.org?format=json", 
        function(data) {   
        $.ajax({  
            url:"select.php",  
            method:"post",  
            data:{id:id, ip: data.ip},  
            success:function(data){ 
                console.log(data);
                $('#item_detail').html(data);
                $('#myModal1').modal("show");  
                }  
        });  
        $.ajax({  
            url:"cart.php",  
            method:"post",  
            data:{ip: data.ip},  
            success:function(data){  
                console.log(data);
                cart.text(data);
            }  
        });
      }); 
    });    


$('.buy-now').on('click', function () {
        var id= $(this).attr('id');
        console.log(id);
        $.getJSON("https://api.ipify.org?format=json", 
        function(data) {   
        $.ajax({  
            url:"select.php",  
            method:"post",  
            data:{id:id, ip: data.ip},  
            success:function(data){ 
                console.log(data);
                location.href= "customer_cart.php";
            }  
        });
      }); 
    });    

});