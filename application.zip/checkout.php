<?php 
session_start();
include("connection.php");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Customer Cart</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Dancing+Script" rel="stylesheet">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/css/bootstrap-select.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js"></script>

<!-- (Optional) Latest compiled and minified JavaScript translation files -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/i18n/defaults-*.min.js"></script>

<style>
#myDiv {
  display: none;
  text-align: center;
}
</style>
</head>
<body class="container">
<div id= "myDiv" class="container" style="display:block;">

    <h1 class="text-center text-black mb-5" 
    style="font-family: 'Abril Fatface'; margin-top: 20px;">
    <span class="fa fa-shopping-cart my-cart-icon"></span>
    Your Cart</h1>

<form action="pay.php" method="post">
<div class="row">
        

<?php
        $some= json_decode($_REQUEST['info']);
        $_SESSION['kela']= $_GET['info'];
        /*echo gettype($some);*/
        $tot= $_REQUEST['total'];
        $items = array();
        foreach($some as $arr) {
            foreach($arr as $key => $value) {
                $items[$key] = $value;
            }
            ?>

            <input type="hidden" name="total_price" value="<?php echo $tot; ?>">
               <div class="d-flex">
                  <div class="p-2"><img style="height: 80px;" class="img-fluid img-thumbnail" src="<?php echo $items['img'];?>"></div>
                  <div class="p-2"><b><i><?php echo $items['name'];?></i></b></div>
                  <div class="p-2"><b><i>Rs <?php echo $items['price'];  ?></i></b></div>
                  <div class="p-2"><b><i>Quantity <?php echo $items['qty'];?></i></b></div>
                </div>
            <?php 
        }
?>
</div>
<div class="col-md-6 animate-box" style="padding-top: 20px; text-align: center;">
        <div class="row form-group">
            <div class="col-md-6">
                <!-- <label for="fname">First Name</label> -->
                <input type="text" name="fname" class="form-control" placeholder="Your firstname" required="true">
            </div>
            <div class="col-md-6">
                <!-- <label for="lname">Last Name</label> -->
                <input type="text" name="lname" class="form-control" placeholder="Your lastname" required="true">
            </div>
        </div>

        <div class="row form-group">
            <div class="col-md-12">
                <!-- <label for="email">Email</label> -->
                <input type="text" name="email" class="form-control" placeholder="Your email address" required="true">
            </div>
        </div>

        <div class="row form-group">
            <div class="col-md-12">
                <!-- <label for="email">Email</label> -->
                <input type="number" name="phone" class="form-control" placeholder="Your Phone No." required="true">
            </div>
        </div>

        <div class="row form-group">
            <div class="col-md-12">
                <!-- <label for="message">Message</label> -->
                <textarea name="address" id="address" cols="30" rows="10" class="form-control" placeholder="Your Delivery Address" required="true"></textarea>
            </div>
        </div>
</div>
    <div class="text-center text-danger mb-5" style="padding-top: 20px;">
    <button name="payment" class="btn btn-success" >Confirm & Pay Rs <?php echo $tot;?> </button>
    </div>
</form>
</div>
</body>
</html>