<?php 
session_start();
include("connection.php");
$ip= $_SESSION['sess_ip'];
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/cart.css" media="screen" title="no title" charset="utf-8">
    <script src="js/jquery.min.js"></script>
    <meta name="robots" content="Customer Cart" />
  </head>
  <body>

<div class="shopping-cart">
  <!-- Title -->
  <div class="title">
    Shopping Cart
  </div>
<script type="text/javascript">
  var products=[];
  var allinfo=[];
</script>
 
<?php 
$q = "SELECT * from cart WHERE ip='$ip'";
$data= mysqli_query($conn, $q);
$grand_total= 0;
if(mysqli_num_rows($data) == 0){
  header("location: index.php");
}
while($res= mysqli_fetch_assoc($data)){
  $grand_total= $grand_total + $res['product_price'];
 ?>
 <script type="text/javascript">
   products.push(<?php echo $res['product_id']; ?>);
 </script>
  <div class="item" id="<?php echo $res['product_id']; ?>">
    <div class="buttons">
      <span class="delete-btn btn-danger"></span>
    </div>
 
    <div class="image">
      <img src="images/<?php echo $res['product_image']; ?>" style="height: 100px; width: 100px;" alt="" />
    </div>
 
    <div class="description">
      <span><?php echo $res['product_name']; ?></span>
    </div>
 
    <div class="quantity">
      <button class="minus-btn" type="button" name="button">
        <img src="https://designmodo.com/demo/shopping-cart/minus.svg" alt="" />
      </button>
     <input type="text" name="name" value="1" id="<?php echo $res['product_price']; ?>">
      <button class="plus-btn" type="button" name="button">
        <img src="https://designmodo.com/demo/shopping-cart/plus.svg" alt="" />
      </button>
    </div>
 
    <div class="total-price"><?php echo $res['product_price']; ?></div>
  </div>
<?php } ?>
<div style="text-align: right; padding-top: 20px; padding-right: 50px; padding-bottom: 20px;">
  <div>
    <span class="grand-total" style="padding-right: 5px;"><b style="color: green;">Total Rs: <span><?php echo $grand_total; ?></span> </b></span>
    <a href="checkout.php" class="btn btn-primary">Proceed to Buy</a>
  </div>
</div>
</div>

<script type="text/javascript">

$(function(){

//console.log(products);
for (var i=0; i< products.length; i++){
  singleinfo={};
  singleinfo["id"]= products[i];
  singleinfo["price"]= $('#'+products[i]).find('.total-price').text();
  singleinfo["qty"]= $('#'+products[i]).find('input').val();
  singleinfo["img"]= $('#'+products[i]).find('img').attr('src');
  singleinfo["name"]= $('#'+products[i]).find('.description').find('span').text();
  allinfo.push(singleinfo);
}

console.log(allinfo);
var total= $('.grand-total').find('span').text();
$('.btn-primary').attr("href", "checkout.php?total="+total+"&info="+JSON.stringify(allinfo));

$('.minus-btn').on('click', function() {
    var price= $(this).closest('div').find('input').attr('id');
    var input = $(this).closest('div').find('input');
    var value = parseInt(input.val());
    var grand= parseInt($('.grand-total').find('span').text());
    //console.log(grand);
    if (value > 0) {
        value = value - 1;
        grand= grand-parseInt(price);
        price= price*value;

    } else {
        value = 0;
        price= 0;
    }
  //console.log(grand);
  input.val(value); 
  $(this).parent().parent().find('.total-price').text(price);
  $('.grand-total').find('span').text(grand);
for (var i=0; i< allinfo.length; i++){
  if(allinfo[i]['id'] == $(this).parent().parent().attr('id')){
    allinfo[i]['price']= $(this).parent().parent().find('.total-price').text();
    allinfo[i]['qty']= parseInt(input.val());
  }
}
console.log(allinfo);
var total= $('.grand-total').find('span').text();
$('.btn-primary').attr("href", "checkout.php?total="+total+"&info="+JSON.stringify(allinfo));
  //$('.btn-primary').attr("href", "checkout.php?total="+$('.grand-total').find('span').text());
})

$('.plus-btn').on('click', function() {
    var price= $(this).closest('div').find('input').attr('id');
    var input = $(this).closest('div').find('input');
    var value = parseInt(input.val());
    var grand= parseInt($('.grand-total').find('span').text());
 
    if (value < 100) {
        value = value + 1;
        grand= grand+parseInt(price);
        price= price*value;
    } else {
        value =100;
        price= price*100;
    }
 
    input.val(value);
    $(this).parent().parent().find('.total-price').text(price);
    $('.grand-total').find('span').text(grand);
 for (var i=0; i< allinfo.length; i++){
  if(allinfo[i]['id'] == $(this).parent().parent().attr('id')){
    allinfo[i]['price']= $(this).parent().parent().find('.total-price').text();
    allinfo[i]['qty']= parseInt(input.val());
  }
}
console.log(allinfo);
var total= $('.grand-total').find('span').text();
$('.btn-primary').attr("href", "checkout.php?total="+total+"&info="+JSON.stringify(allinfo));
    //$('.btn-primary').attr("href", "checkout.php?total="+$('.grand-total').find('span').text());
})

$('.delete-btn').on('click', function(){
  var id= $(this).parent().parent().attr('id');
  console.log(id)
  $.ajax({  
    url:"cart-delete.php",  
    method:"post",  
    data:{id:id},  
    success:function(data){ 
      location.reload();
    }  
  })
})

})
</script>
</body>
</html>