<?php 
session_start();
include("connection.php");
require './phpmailer/PHPMailerAutoload.php';
$name= $_SESSION['name'];
$phone= $_SESSION['phone'];
$address= $_SESSION['address'];
$total_price= $_SESSION['total'];
$allvalues= $_SESSION['kela'];


/*function send_email_customer($name, $details, $payid, $total_price, $vendor_name, $vendor_phone, $vendor_address, $date){
$mail = new PHPMailer;

$htmlversion= "<b><i>Order Details</i></b> <br> Product: <b>".$details."</b> <br> Order ID: <b>".$payid."</b> <br> Total Amount Paid: <b>".$total_price."</b> <br> Vendor Name: <b>".$vendor_name."</b> <br> Vendor Phone No: <b>".$vendor_phone."</b> <br> Vendor Address <b>".$vendor_address."</b> <br> Date <b>".$date."</b> <br> <b><i> Thank you for ordering with Lakilaka </i></b>";
$textversion= 'Order Successful';

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;
//$mail->SMTPDebug = 1;                               // Enable SMTP authentication
$mail->Username = 'rfidlibrarypccoe@gmail.com';                 // SMTP username
$mail->Password = 'spmnigdi@44';                           // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                    // TCP port to connect to

$mail->setFrom('rfidlibrarypccoe@gmail.com', 'Lakilaka');
$mail->addAddress($name);               // Name is optional

$mail->isHTML(true);

$mail->Subject = 'Order Successful';
$mail->Body    = $htmlversion;
$mail->AltBody = $textversion;

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    
}
}*/
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment Success Page</title>
 <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

</head>
<body>
	<div class="container">
		<div class="row justify-content-center">
			<div class="table-responsive">
				<?php 
					include("./instamojo/Instamojo.php");
					$api = new Instamojo\Instamojo('978345a1bb01122d0848b1f98ce7b044', '4d4762934c52003c4231247b46066259');
					$pay_id= $_GET['payment_request_id'];
					try{
						$response= $api->paymentRequestStatus($pay_id);
						$email= $response['payments'][0]['buyer_email'];
						$payid= $response['payments'][0]['payment_id'];
						?>
						<h2 class="text-center text-black mb-5" style="margin-top: 20px;"> Payment Details </h2>
						<table class="table table-bordered" style="margin-top: 40px;">
							<tr>
								<th>Purchased from</th>
								<td><?= $response['purpose']; ?></td>
							</tr>
							<tr>
								<th>Payment ID</th>
								<td><?= $response['payments'][0]['payment_id']; ?></td>
							</tr>
							<tr>
								<th>Buyer Name</th>
								<td><?= $name; ?></td>
							</tr>
							<tr>
								<th>Buyer Phone No.</th>
								<td><?= $phone; ?></td>
							</tr>
							<tr>
								<th>Buyer Email</th>
								<td><?= $response['payments'][0]['buyer_email']; ?></td>
							</tr>
							<tr>
								<th>Buyer Address</th>
								<td><?= $address; ?></td>
							</tr>
							<tr>
								<th>Total Amount Paid</th>
								<td>Rs <?= $total_price; ?></td>
							</tr>
							<tr>
								<th>Payment Status</th>
								<td><?= $response['payments'][0]['status']; ?></td>
							</tr>
							<tr>
								<th>Order Date</th>
								<td><?php 		    
								date_default_timezone_set('Asia/Kolkata');
								$date = date('d/m/Y H:i:s', time());
								echo $date;?></td>
							</tr>
						</table>
		<?php
		$some= json_decode($_SESSION['kela']);
		$items2= array();
		$details= '';
		foreach($some as $arr2) {
			foreach($arr2 as $key2 => $value2) {
				$items2[$key2] = $value2;
				}
		$details= $details.$items2['name'].' Qty: '.$items2['qty'].',';
		}
		$q = "INSERT INTO orders VALUES(DEFAULT, '1', '$name', '$email', '$phone', '$payid', '$details', 'Not Started', '$date', '$address', '$total_price')";
		if(mysqli_query($conn, $q)){
		echo "<script>alert('Order Placed');</script>";
		$q4 = "SELECT * FROM vendors WHERE id = '1'"; 
		$data4= mysqli_query($conn, $q4);
		$res4= mysqli_fetch_assoc($data4);
		$vendor_name= $res4['name'];
		$vendor_phone= $res4['phone_no'];
		$vendor_address= $res4['address'];
		//send_email_customer($email, $details, $payid, $total_price, $vendor_name, $vendor_phone, $vendor_address, $date);
		}
		else{
		echo mysqli_error($conn);
		echo "<script>alert('Error placing order');</script>";
		} 
		}
	catch (Exception $e) {
		print('Error: ' . $e->getMessage());
		}
		?>
<div class="text-center text-danger mb-2">
	<button name="shopping" class="btn btn-success" onclick='window.location.href = "http://lakilaka.in/index.php"'>Continue Shoppping</button>
</div>
			</div>
		</div>
	</div>

</body>
</html>