<?php
session_start();
/*ini_set('display_errors', 1);*/

$allvalues= $_SESSION['kela'];
$_SESSION['address']= htmlspecialchars($_POST['address']);
$_SESSION['name']= $_POST['fname']." ".$_POST['lname'];
$_SESSION['phone']= $_POST['phone'];
$_SESSION['total']= $_POST['total_price'];
//print_r($cust_name);

$some= json_decode($allvalues);
//print_r($some);

$items = array();
foreach($some as $arr) {
    foreach($arr as $key => $value) {
        $items[$key] = $value;
    }
    /*print_r($items);
    echo "<br />";*/
}


include("./instamojo/Instamojo.php");
$api = new Instamojo\Instamojo('978345a1bb01122d0848b1f98ce7b044', '4d4762934c52003c4231247b46066259');
//$api = new Instamojo\Instamojo('test_1893cda3724555853115c973acd', 'test_e5f0906c73a453e3cc3283ff86a','https://test.instamojo.com/api/1.1/');

try {
$response = $api->paymentRequestCreate(array(
    "purpose" => "Lakilaka",
    "amount" => $_POST['total_price'],
    "send_email" => true,
    "email" => $_POST['email'],
    "allow_repeated_payments" => false,
    "redirect_url" => "http://lakilaka.in/pay_success.php",
    ));
print_r($response);
$pay_url=$response['longurl'];
header("location:$pay_url");
}
catch (Exception $e) {
print('Error: ' . $e->getMessage());
}
?>