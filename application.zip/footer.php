<footer id="fh5co-footer" role="contentinfo">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-4 fh5co-widget">
					<h3>Lakilaka</h3>
					<p>At Lakilaka you will find a wide range of products to choose from. Shop for your favorite wines, get the best furntiure for your home and manage your personal care with the best soaps and shampoo products.</p>
				</div>
				<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1">
					<ul class="fh5co-footer-links">
						<li><a href="#">About</a></li>
						<li><a href="#">Contact</a></li>
						<li><a href="#">Terms</a></li>
					</ul>
				</div>

				<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1">
					<ul class="fh5co-footer-links">
						<li><a href="index.php">Shop</a></li>
						<li><a href="product.php?cat=Furniture">Furniture</a></li>
						<li><a href="product.php?cat=Wines">Wines</a></li>
						<li><a href="product.php?cat=Soaps and Shampoos">Soaps and Shampoo</a></li>
					</ul>
				</div>

				<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1">
					<ul class="fh5co-footer-links">
					</ul>
				</div>
			</div>

			<div class="row copyright">
				<div class="col-md-12 text-center">
					<p>
						<small class="block">&copy; 2020, Lakilaka. All Rights Reserved.</small> 
						<small class="block">Designed by <a href="index.php" target="_blank">Lakilaka</a>
					</p>
				</div>
			</div>

		</div>
	</footer>